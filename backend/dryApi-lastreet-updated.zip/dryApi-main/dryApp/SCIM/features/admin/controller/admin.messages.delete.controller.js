const asyncHandler = require('express-async-handler');
const sendResponse = require('../../../../../dry/utils/response');

const MessageSchema = require('../../message/model/message.schema');

module.exports = asyncHandler(async (req, res) => {
    const Message = req.getModel('Message', MessageSchema);

    const message = await Message.findByIdAndDelete(req.params.id);
    if (!message) return sendResponse(res, null, 'Message non trouvé', false);

    return sendResponse(res, null, 'Message supprimé avec succès');
});
